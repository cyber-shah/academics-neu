/**
 * The color of the piece.
 * This enum is used to represent the color of the piece.
 */
public enum Color {
  BLACK,
  WHITE
}
