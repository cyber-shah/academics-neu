# README

1. Navigate to the folder using the terminal
2. Run the python file using "python3 Hw8ShahP.py"
3. Enter SQL id and password
4. Enter a Genre ID