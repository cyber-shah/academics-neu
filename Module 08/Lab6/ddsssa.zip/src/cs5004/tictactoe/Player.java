package cs5004.tictactoe;

/**
 * Represents the two players in a game of tic tac toe.
 * X always goes first.
 */
public enum Player { X, O }
