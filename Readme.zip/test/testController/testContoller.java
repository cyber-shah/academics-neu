package testController;

import controller.ControllerImplementation;
import controller.ControllerInterface;
import controller.commandsStrategy.CommandStrategyInterface;
import model.ImageDatabase;
import model.ImageDatabaseInterface;
import org.junit.Before;
import org.junit.Test;
import view.ViewImplementation;
import view.ViewInterface;

import java.io.StringReader;
import java.util.Map;
import java.util.Scanner;

public class testContoller {
  private ImageDatabaseInterface imageDatabase;
  private ViewInterface view;
  private Readable inReadable;

  @Before
  public void setUp() {
    imageDatabase = new ImageDatabase();
    StringBuilder viewLog = new StringBuilder();
    view = new ViewImplementation(viewLog);
  }
  @Test
  public void testLoadCommand() {
    inReadable = new StringReader("LOAD\n" +
            "C:\\Users\\james\\Desktop\\test\\testController\\testContoller.java\n" +
            "SAVE\n" +
            "C:\\Users\\james\\Desktop\\test\\testController\\testContoller.java\n" +
            "BRIGHTEN\n" +
            "LUMA\n" +
            "INTENSITY\n" +
            "VALUE\n" +
            "COMPONENT\n" +
            "EXIT\n");
    ControllerInterface controller = new ControllerImplementation(imageDatabase, view, inReadable);
  }
}
