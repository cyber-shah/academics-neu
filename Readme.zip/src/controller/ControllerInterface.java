package controller;

public interface ControllerInterface {
  void go();
}
