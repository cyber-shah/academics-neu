package model.Image;

public interface IPixelState {
  int getRed();
  int getGreen();
  int getBlue();
  int getMaxValue();
}
