package model.Image;

public interface IPixel extends IPixelState {
  void setRed(int red);
  void setGreen(int green);
  void setBlue(int blue);
}
