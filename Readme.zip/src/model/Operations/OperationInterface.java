package model.Operations;

import model.Image.ImageState;

public interface OperationInterface {

  ImageState applyOperation();
}
