package view;

import java.io.IOException;

public interface ViewInterface {
  void renderMessage(String message) throws IOException;
}
